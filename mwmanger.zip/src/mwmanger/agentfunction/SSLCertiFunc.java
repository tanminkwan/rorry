package mwmanger.agentfunction;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.logging.Level;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import mwmanger.common.Common;
import mwmanger.common.Config;
import mwmanger.vo.CommandVO;
import mwmanger.vo.ResultVO;

public class SSLCertiFunc implements AgentFunc {

	private String domain = "";
	private ResultVO rv = new ResultVO();

	@Override
	public ArrayList<ResultVO> exeCommand(CommandVO command) throws Exception {

		String param = command.getAdditionalParams();
		
		rv.setOk(false);

		String url = "https://" + param;
		domain = param;
		
		httpsGet(url);
		
		return Common.makeOneResultArray(rv, command);
	
	}

    private void httpsGet(String strURL) throws Exception
    {
        URL url = null;
        HttpsURLConnection con = null;
        
        try {
            url = new URL(strURL);
            ignoreSsl();
            con = (HttpsURLConnection) url.openConnection();
            con.setConnectTimeout(3000);
            con.getInputStream();

        }
        catch (UnknownHostException e){
        	Config.getLogger().log(Level.WARNING, e.getMessage(), e);
        	rv.setResult("UnknownHostException occured");
        }
        catch (ConnectException e){
        	Config.getLogger().log(Level.WARNING, e.getMessage(), e);
        	rv.setResult("ConnectException occured");
        }
        catch (SocketTimeoutException e){
        	Config.getLogger().log(Level.WARNING, e.getMessage(), e);
        	rv.setResult("SocketTimeoutException occured");
        }        
        catch (IOException e) {
        } 
        finally {
            if (con != null) {
                con.disconnect();
            }
        }
        
    }
    
    private void ignoreSsl() throws Exception{
        HostnameVerifier hv = new HostnameVerifier() {
        public boolean verify(String urlHostName, SSLSession session) {
                return true;
            }
        };
        trustAllHttpsCertificates();
        HttpsURLConnection.setDefaultHostnameVerifier(hv);
    }

    private void trustAllHttpsCertificates() throws Exception {
        TrustManager[] trustAllCerts = new TrustManager[1];
        TrustManager tm = new miTM();
        trustAllCerts[0] = tm;
        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, null);
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
    }
 
    class miTM implements TrustManager,X509TrustManager {

    	public X509Certificate[] getAcceptedIssuers() {
            return null;
        }
 
        public boolean isServerTrusted(X509Certificate[] certs) {
            return true;
        }
 
        public boolean isClientTrusted(X509Certificate[] certs) {
            return true;
        }
 
        public void checkServerTrusted(X509Certificate[] certs, String authType)
                throws CertificateException {

        	StringBuilder json = new StringBuilder();
            json.append("{\"domain\":\"" + domain + "\",\"certs\":[");

            int i = 0;
    		for(X509Certificate c:certs){
    			i++;
    			//System.out.println("getType : "+c.getType());
    			//System.out.println("getVersion : "+Integer.toString(c.getVersion()));
    			//System.out.println("getNotAfter : "+c.getNotAfter().toString());
    			//System.out.println("getNotBefore : "+c.getNotBefore().toString());
    			//System.out.println("getSubjectDN : "+c.getSubjectDN().getName());
    			//System.out.println("getSerialNumber : "+c.getSerialNumber().toString());
    			//System.out.println("getSerialNumber 16 : "+c.getSerialNumber().toString(16));
    			//System.out.println("getSerialNumber 16 z: "+String.format("%032X", c.getSerialNumber()));
    			//System.out.println("getIssuerDN : "+c.getIssuerDN().getName());
                
    			json.append("{");
    			json.append("\"index\":\""+Integer.toString(i)+"\",");
    			json.append("\"notafter\":\""+c.getNotAfter().toString()+"\",");
    			json.append("\"notbefore\":\""+c.getNotBefore().toString()+"\",");
    			json.append("\"serial\":\""+String.format("%032X", c.getSerialNumber())+"\",");
    			json.append("\"issuer\":\""+c.getIssuerDN().getName()+"\",");
                json.append("\"subject\":\""+c.getSubjectDN().getName()+"\"");
                json.append("}");
                if(i!=certs.length){
                	json.append(",");
                }
    		}
        
    		json.append("]}");
    		rv.setResult(json.toString());
    		rv.setOk(true);

            return;
        }
 
        public void checkClientTrusted(X509Certificate[] certs, String authType)
        		throws CertificateException {
        	return;
        }
    }

}
